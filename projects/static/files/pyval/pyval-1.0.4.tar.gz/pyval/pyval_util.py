#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" PyVal Utilities Module
    Holds globally shared info about pyval.
"""

NAME = 'PyVal'
VERSION = '1.0.4'
VERSIONSTR = '{} v. {}'.format(NAME, VERSION)
